function updateProfile() {
    alert("Profile updated successfully!");
}
