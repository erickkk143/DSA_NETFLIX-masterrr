console.log("Homepage loaded successfully!");
