function redirectToHome() {
    window.location.href = "homepage.html"; // Replace with your actual homepage file or link.
}
